from pipelines.preprocess import to_clean_df

def test_to_clean_df():
    rows = [
        {"ts":1,"exchange":"binance","symbol":"BTCUSDT","interval":"1m","open":1,"high":2,"low":1,"close":2,"volume":10},
        {"ts":1,"exchange":"binance","symbol":"BTCUSDT","interval":"1m","open":1,"high":2,"low":1,"close":2,"volume":10}
    ]
    df = to_clean_df(rows)
    assert len(df)==1
    print("✅ Test OK — pas de doublon, schéma valide")
