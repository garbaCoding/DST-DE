
# 🚀 Crypto-DST — Étape 1 : Récolte, Extraction & Transformation

Version : 2025-10-11 04:40 UTC

## 📦 Structure du projet

crypto-dst/
├── src/providers/         → interfaces & API (Binance, Coinbase, etc.)
├── src/pipelines/         → ingestion + préprocessing
├── src/storage/           → fonctions d’écriture (Parquet, JSONL)
├── data/raw/              → données brutes (JSONL)
├── data/clean/            → données normalisées (Parquet)
├── tests/                 → scripts de test
├── .env.example
└── README.md
