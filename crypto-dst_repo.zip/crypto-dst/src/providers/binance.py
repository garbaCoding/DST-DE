import time, requests
from typing import Iterable, Dict, Any
from .base import MarketDataProvider

BASE = "https://api.binance.com"

class BinanceProvider(MarketDataProvider):
    name = "binance"

    def fetch_klines(self, symbol, interval, start_ms, end_ms) -> Iterable[Dict[str, Any]]:
        url = f"{BASE}/api/v3/klines"
        params = {"symbol": symbol, "interval": interval, "startTime": start_ms, "endTime": end_ms, "limit": 1000}
        ts = start_ms
        while True:
            params["startTime"] = ts
            r = requests.get(url, params=params, timeout=30)
            r.raise_for_status()
            chunk = r.json()
            if not chunk: break
            for k in chunk:
                yield k
            ts = chunk[-1][0] + 60_000
            if ts >= end_ms: break
            time.sleep(0.2)

    def normalize_kline(self, k, symbol: str, interval: str) -> Dict[str, Any]:
        open_ts = int(k[0])
        return {
            "ts": open_ts,
            "t_open_iso": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(open_ts/1000)),
            "exchange": "binance",
            "market_type": "spot",
            "symbol": symbol,
            "base": symbol[:-4] if symbol.endswith("USDT") else symbol,
            "quote": "USDT" if symbol.endswith("USDT") else "",
            "interval": interval,
            "open": float(k[1]), "high": float(k[2]), "low": float(k[3]), "close": float(k[4]),
            "volume": float(k[5]),
            "trades": int(k[8]) if len(k) > 8 and k[8] is not None else None,
            "source": "binance",
            "ingest_ts": int(time.time()*1000),
        }
