from abc import ABC, abstractmethod
from typing import Iterable, Dict, Any

class MarketDataProvider(ABC):
    name: str

    @abstractmethod
    def fetch_klines(self, symbol: str, interval: str, start_ms: int, end_ms: int) -> Iterable[Dict[str, Any]]:
        ...

    def normalize_kline(self, raw: Dict[str, Any], symbol: str, interval: str) -> Dict[str, Any]:
        raise NotImplementedError
