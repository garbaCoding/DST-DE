import time
from providers.binance import BinanceProvider
from pipelines.preprocess import to_clean_df

def run(symbols=("BTCUSDT","ETHUSDT"), start_ms=None, end_ms=None, interval="1m"):
    if end_ms is None: end_ms = int(time.time())*1000
    if start_ms is None: start_ms = end_ms - 60*60*1000  # dernière heure
    prov = BinanceProvider()
    rows = []
    for sym in symbols:
        for raw in prov.fetch_klines(sym, interval, start_ms, end_ms):
            rows.append(prov.normalize_kline(raw, sym, interval))
    df = to_clean_df(rows)
    df.to_json("data/sample_clean.json", orient="records", lines=True)
    return df
