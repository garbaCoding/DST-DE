import pandas as pd

REQUIRED = ["ts","exchange","symbol","interval","open","high","low","close","volume"]

def to_clean_df(rows):
    df = pd.DataFrame(rows)
    df["ts"] = df["ts"].astype("int64")
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["key"] = df["exchange"]+"|"+df["symbol"]+"|"+df["interval"]+"|"+df["ts"].astype(str)
    df = df.drop_duplicates("key").dropna(subset=REQUIRED)
    df = df.sort_values(["exchange","symbol","ts"]).reset_index(drop=True)
    return df.drop(columns=["key"])
