{% macro export_results() %}
    {% set queries = [
        ('analytics_3_7_top_genre_2000s', 'genre_2000s.csv'),
        ('analytics_top_artists', 'top_artists.csv')
    ] %}
    
    {% for model, filename in queries %}
        COPY INTO @~/exports/{{ filename }}
        FROM {{ ref(model) }}
        FILE_FORMAT = (TYPE = CSV HEADER = TRUE);
    {% endfor %}
{% endmacro %}
