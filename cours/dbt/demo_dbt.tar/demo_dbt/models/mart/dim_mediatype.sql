{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    mediatypeid as mediatype_key,
    name as mediatype_name,
    current_timestamp() as created_at
from {{ ref('stg_mediatypes') }}
