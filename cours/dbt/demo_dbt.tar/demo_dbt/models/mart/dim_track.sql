{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    trackid as track_key,
    track_name,                       
    albumid as album_key,
    genreid as genre_key,
    mediatypeid as mediatype_key,
    composer,
    milliseconds,
    bytes,
    unitprice,
    current_timestamp() as created_at
from {{ ref('stg_tracks') }}
