{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    genreid as genre_key,
    name as genre_name,
    current_timestamp() as created_at
from {{ ref('stg_genres') }}
