{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    artistid as artist_key,
    name as artist_name,
    current_timestamp() as created_at
from {{ ref('stg_artists') }}
