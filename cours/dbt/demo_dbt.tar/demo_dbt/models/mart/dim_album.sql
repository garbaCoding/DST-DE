{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    a.albumid as album_key,
    a.title as album_name,
    ar.artistid as artist_key,
    ar.name as artist_name,              
    current_timestamp() as created_at
from {{ ref('stg_albums') }} a
left join {{ ref('stg_artists') }} ar on a.artistid = ar.artistid
