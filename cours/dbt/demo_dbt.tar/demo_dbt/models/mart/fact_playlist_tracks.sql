{{ config(
    materialized='table',
    tags=['fact']
) }}

select
    pt.playlistid as playlist_key,
    pt.trackid as track_key,
    t.albumid as album_key,              
    t.genreid as genre_key,              
    t.mediatypeid as mediatype_key,      
    1 as track_count,
    t.milliseconds,
    t.bytes,
    t.unitprice,
    current_timestamp() as created_at
from {{ ref('stg_playlisttrack') }} pt
inner join {{ ref('stg_tracks') }} t on pt.trackid = t.trackid
