{{ config(
    materialized='table',
    tags=['dimension']
) }}

select
    playlistid as playlist_key,
    playlist_name,                    
    current_timestamp() as created_at
from {{ ref('stg_playlists') }}
