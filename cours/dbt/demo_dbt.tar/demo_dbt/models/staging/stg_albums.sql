{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    albumid,
    title,
    artistid
from {{ source('music_db', 'album') }}
