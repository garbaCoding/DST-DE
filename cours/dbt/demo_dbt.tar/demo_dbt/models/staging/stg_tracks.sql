{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    trackid,
    title as track_name,    -- ✅ Renommer pour cohérence
    albumid,
    mediatypeid,
    genreid,
    composer,
    milliseconds,
    bytes,
    unitprice
from {{ source('music_db', 'track') }}
