{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    playlistid,
    NAME as playlist_name
from {{ source('music_db', 'playlist') }}
