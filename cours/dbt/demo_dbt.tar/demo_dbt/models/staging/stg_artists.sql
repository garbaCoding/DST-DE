{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    artistid,
    name
from {{ source('music_db', 'artist') }}
