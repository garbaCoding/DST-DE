{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    playlistid,
    trackid
from {{ source('music_db', 'playlisttrack') }}
