{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    genreid,
    name
from {{ source('music_db', 'genre') }}
