{{ config(
    materialized='view',
    tags=['staging']
) }}

select
    mediatypeid,
    name
from {{ source('music_db', 'mediatype') }}
