{{ config(
    materialized='view',
    tags=['analytics', 'playlist_analysis']
) }}

-- 3.11. Playlists avec morceaux d'artistes nés avant 1990
select distinct
    p.playlist_name,
    ar.artist_name,
    null as artist_birth_year 
from {{ ref('dim_playlist') }} p
inner join {{ ref('fact_playlist_tracks') }} fpt on p.playlist_key = fpt.playlist_key
inner join {{ ref('dim_track') }} t on fpt.track_key = t.track_key
inner join {{ ref('dim_album') }} al on t.album_key = al.album_key
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
where 1=0 