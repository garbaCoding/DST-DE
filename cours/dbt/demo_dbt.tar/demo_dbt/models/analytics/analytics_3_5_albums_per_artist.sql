{{ config(
    materialized='view',
    tags=['analytics', 'artist_analysis']
) }}

-- 3.5. Nombre d'albums par artiste
select
    ar.artist_name,
    count(distinct al.album_key) as album_count
from {{ ref('dim_artist') }} ar
inner join {{ ref('dim_album') }} al on ar.artist_key = al.artist_key
group by ar.artist_name
order by album_count desc, ar.artist_name
