{{ config(
    materialized='view',
    tags=['analytics', 'album_analysis']
) }}

-- 3.4. Top 10 des albums les plus longs (en millisecondes)
select
    al.album_name,
    ar.artist_name,
    sum(t.milliseconds) as total_duration_ms,
    round(sum(t.milliseconds) / 1000.0 / 60.0, 2) as total_duration_minutes,
    count(t.track_key) as track_count
from {{ ref('dim_album') }} al
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
inner join {{ ref('dim_track') }} t on al.album_key = t.album_key
group by al.album_name, ar.artist_name
order by total_duration_ms desc
limit 10
