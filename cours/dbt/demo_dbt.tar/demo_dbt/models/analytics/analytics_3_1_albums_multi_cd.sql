{{ config(
    materialized='view',
    tags=['analytics', 'album_analysis']
) }}

-- 3.1. Albums avec plus de 1 CD
select
    al.album_name,
    ar.artist_name,
    count(t.track_key) as track_count,
    case 
        when count(t.track_key) > 20 then 2
        when count(t.track_key) > 40 then 3
        else 1
    end as estimated_cd_count
from {{ ref('dim_album') }} al
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
inner join {{ ref('dim_track') }} t on al.album_key = t.album_key
group by al.album_name, ar.artist_name
having count(t.track_key) > 20
order by track_count desc
