{{ config(
    materialized='view',
    tags=['analytics', 'genre_analysis']
) }}

-- 3.3. Morceaux de Rock et Jazz avec compositeurs
select
    g.genre_name,
    ar.artist_name,
    al.album_name,
    t.track_name,
    t.composer
from {{ ref('dim_track') }} t
inner join {{ ref('dim_genre') }} g on t.genre_key = g.genre_key
inner join {{ ref('dim_album') }} al on t.album_key = al.album_key
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
where g.genre_name in ('Rock', 'Jazz')
    and t.composer is not null
order by g.genre_name, ar.artist_name, t.track_name
