{{ config(
    materialized='view',
    tags=['analytics', 'artist_analysis']
) }}

-- 3.6. Nombre de morceaux par artiste
select
    ar.artist_name,
    count(t.track_key) as track_count,
    count(distinct al.album_key) as album_count
from {{ ref('dim_artist') }} ar
inner join {{ ref('dim_album') }} al on ar.artist_key = al.artist_key
inner join {{ ref('dim_track') }} t on al.album_key = t.album_key
group by ar.artist_name
order by track_count desc, ar.artist_name
