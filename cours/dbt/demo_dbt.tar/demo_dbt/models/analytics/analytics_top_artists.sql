{{ config(
    materialized='view',
    tags=['analytics', 'reporting']
) }}

-- Top 10 artistes par nombre de morceaux
select
    a.artist_name,
    count(distinct t.track_key) as track_count,
    count(distinct al.album_key) as album_count
from {{ ref('dim_artist') }} a
inner join {{ ref('dim_album') }} al on a.artist_key = al.artist_key
inner join {{ ref('dim_track') }} t on al.album_key = t.album_key
group by a.artist_name
order by track_count desc
limit 10