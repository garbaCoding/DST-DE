{{ config(
    materialized='table',
    tags=['analytics']
) }}

-- 3.7. Donnez le genre de musique le plus écouté dans les années 2000

select
    g.genre_name,
    count(distinct t.track_key) as nombre_morceaux
from {{ ref('dim_genre') }} g
join {{ ref('dim_track') }} t on g.genre_key = t.genre_key
where t.composer like '%200_%'
   or t.composer like '%2000%'
   or t.composer like '%2001%'
   or t.composer like '%2002%'
   or t.composer like '%2003%'
   or t.composer like '%2004%'
   or t.composer like '%2005%'
   or t.composer like '%2006%'
   or t.composer like '%2007%'
   or t.composer like '%2008%'
   or t.composer like '%2009%'
group by g.genre_key, g.genre_name
order by nombre_morceaux desc
limit 1
