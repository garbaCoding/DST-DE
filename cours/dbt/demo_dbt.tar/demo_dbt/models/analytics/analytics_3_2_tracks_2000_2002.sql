{{ config(
    materialized='view',
    tags=['analytics', 'track_analysis']
) }}

-- 3.2. Morceaux produits en 2000 ou 2002
select
    t.track_name,
    t.composer,
    ar.artist_name,
    al.album_name,
    case
        when t.composer like '%2000%' then 2000
        when t.composer like '%2002%' then 2002
    end as production_year
from {{ ref('dim_track') }} t
inner join {{ ref('dim_album') }} al on t.album_key = al.album_key
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
where t.composer like '%2000%' 
   or t.composer like '%2002%'
order by production_year, t.track_name
