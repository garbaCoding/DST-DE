{{ config(
    materialized='view',
    tags=['analytics', 'genre_analysis']
) }}

-- 3.9. Morceaux de Rock d'artistes français
select
    t.track_name,
    ar.artist_name,
    g.genre_name,
    null as artist_country 
from {{ ref('dim_track') }} t
inner join {{ ref('dim_genre') }} g on t.genre_key = g.genre_key
inner join {{ ref('dim_album') }} al on t.album_key = al.album_key
inner join {{ ref('dim_artist') }} ar on al.artist_key = ar.artist_key
where g.genre_name = 'Rock'
    and 1=0 
