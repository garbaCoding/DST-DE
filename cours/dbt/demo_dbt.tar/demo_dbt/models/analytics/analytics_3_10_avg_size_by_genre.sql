{{ config(
    materialized='view',
    tags=['analytics', 'genre_analysis']
) }}

-- 3.10. Moyenne des tailles des morceaux par genre
select
    g.genre_name,
    count(t.track_key) as track_count,
    round(avg(t.bytes), 0) as avg_size_bytes,
    round(avg(t.bytes) / 1024.0 / 1024.0, 2) as avg_size_mb,
    round(avg(t.milliseconds) / 1000.0 / 60.0, 2) as avg_duration_minutes
from {{ ref('dim_genre') }} g
inner join {{ ref('dim_track') }} t on g.genre_key = t.genre_key
where t.bytes is not null
group by g.genre_name
order by avg_size_bytes desc
