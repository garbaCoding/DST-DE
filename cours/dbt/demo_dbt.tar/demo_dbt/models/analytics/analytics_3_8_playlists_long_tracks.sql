{{ config(
    materialized='view',
    tags=['analytics', 'playlist_analysis']
) }}

-- 3.8. Playlists avec morceaux de plus de 4 minutes (240000 ms)
select distinct
    p.playlist_name,
    count(distinct t.track_key) as long_track_count
from {{ ref('dim_playlist') }} p
inner join {{ ref('fact_playlist_tracks') }} fpt on p.playlist_key = fpt.playlist_key
inner join {{ ref('dim_track') }} t on fpt.track_key = t.track_key
where t.milliseconds > 240000
group by p.playlist_name
order by long_track_count desc, p.playlist_name
